import './App.css';
import Form from './components/Form';

function App() {
  return (
    <div className="App">
      <h1>Product Manager</h1>
      <Form />
    </div>
  );
}

export default App;
